from pathlib import Path

gradle_file = Path("android/app/build.gradle.kts")
if not gradle_file.is_file():
    raise SystemExit("ERROR: android/app/build.gradle.kts was not generated.")

text = gradle_file.read_text(encoding="utf-8")
if "checkReleaseBuilds = false" not in text:
    marker = "android {"
    if marker not in text:
        raise SystemExit("ERROR: Could not find android { block in build.gradle.kts.")
    text = text.replace(
        marker,
        marker + """
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
""",
        1,
    )

gradle_file.write_text(text, encoding="utf-8")
print("Release lint checks disabled in android/app/build.gradle.kts")
