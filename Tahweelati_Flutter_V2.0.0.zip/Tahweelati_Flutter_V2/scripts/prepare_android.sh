#!/usr/bin/env bash
set -euo pipefail
flutter create --platforms=android --org com.loay --project-name tahweelati .
