import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:url_launcher/url_launcher.dart';

const Color navy = Color(0xFF0B1220);
const Color green = Color(0xFF1B9A2F);
const Color purple = Color(0xFF4B2A9B);
const Color burgundy = Color(0xFF8B1538);
const String balanceCode = '*268*3#';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await LocalStore.instance.database;
  runApp(const TahweelatiApp());
}

class TahweelatiApp extends StatefulWidget {
  const TahweelatiApp({super.key});
  @override
  State<TahweelatiApp> createState() => _TahweelatiAppState();
}

class _TahweelatiAppState extends State<TahweelatiApp> {
  ThemeMode mode = ThemeMode.system;
  @override
  void initState() { super.initState(); _loadMode(); }
  Future<void> _loadMode() async {
    final prefs = await SharedPreferences.getInstance();
    final value = prefs.getString('theme_mode') ?? 'system';
    if (!mounted) return;
    setState(() => mode = value == 'dark' ? ThemeMode.dark : value == 'light' ? ThemeMode.light : ThemeMode.system);
  }
  Future<void> setMode(ThemeMode value) async {
    setState(() => mode = value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('theme_mode', value.name);
  }
  ThemeData _theme(bool dark) {
    final base = ThemeData(
      useMaterial3: true,
      brightness: dark ? Brightness.dark : Brightness.light,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF1479D5),
        brightness: dark ? Brightness.dark : Brightness.light,
        surface: dark ? const Color(0xFF172235) : Colors.white,
      ),
      scaffoldBackgroundColor: dark ? navy : const Color(0xFFF4F7FB),
    );
    return base.copyWith(
      textTheme: base.textTheme,
      appBarTheme: const AppBarTheme(centerTitle: true, elevation: 0),
      cardTheme: CardThemeData(
        elevation: dark ? 0 : 2,
        color: dark ? const Color(0xFF172235) : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        shadowColor: Colors.black.withValues(alpha: .07),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: dark ? const Color(0xFF202D42) : const Color(0xFFF5F7FA),
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFF1684E8), width: 1.5)),
      ),
    );
  }
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'تحويلاتي',
    theme: _theme(false),
    darkTheme: _theme(true),
    themeMode: mode,
    locale: const Locale('ar'),
    builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox()),
    home: MainShell(mode: mode, onModeChanged: setMode),
  );
}

class LocalStore {
  LocalStore._();
  static final instance = LocalStore._();
  Database? _db;
  Future<Database> get database async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'tahweelati_v2.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute("CREATE TABLE transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, wallet TEXT NOT NULL, title TEXT NOT NULL, phone TEXT NOT NULL, amount TEXT NOT NULL, details TEXT NOT NULL DEFAULT '', code TEXT NOT NULL, createdAt TEXT NOT NULL, type TEXT NOT NULL)");
    });
    return _db!;
  }
  Future<void> add(Map<String, Object?> row) async { await (await database).insert('transactions', row); }
  Future<List<Map<String, Object?>>> all() async => (await database).query('transactions', orderBy: 'id DESC');
  Future<void> clear() async { await (await database).delete('transactions'); }
}

class MainShell extends StatefulWidget {
  final ThemeMode mode;
  final ValueChanged<ThemeMode> onModeChanged;
  const MainShell({super.key, required this.mode, required this.onModeChanged});
  @override
  State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int tab = 0;
  int refresh = 0;
  void openWallet(String wallet) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => WalletPage(wallet: wallet, onSaved: () => setState(() => refresh++))));
    setState(() => refresh++);
  }
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onWallet: openWallet, onHistory: () => setState(() => tab = 2), onSaved: () => setState(() => refresh++)),
      HistoryPage(key: ValueKey(refresh)),
      MorePage(mode: widget.mode, onModeChanged: widget.onModeChanged),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'السجل'),
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), selectedIcon: Icon(Icons.grid_view), label: 'المزيد'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final ValueChanged<String> onWallet;
  final VoidCallback onHistory;
  final VoidCallback onSaved;
  const HomePage({super.key, required this.onWallet, required this.onHistory, required this.onSaved});
  @override
  Widget build(BuildContext context) {
    return CustomScrollView(slivers: [
      SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            _circleAction(context, Icons.notifications_none_rounded, () => _message(context, 'لا توجد إشعارات جديدة')),
            const Text('أهلاً بك 👋', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
            _circleAction(context, Icons.settings_outlined, onHistory),
          ]),
          const SizedBox(height: 16),
          ClipRRect(borderRadius: BorderRadius.circular(28), child: SizedBox(
            height: 238,
            child: Stack(fit: StackFit.expand, children: [
              Image.asset('assets/images/jerusalem.png', fit: BoxFit.cover),
              DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(
                begin: Alignment.centerRight, end: Alignment.centerLeft,
                colors: [navy.withValues(alpha: .88), navy.withValues(alpha: .38), Colors.transparent],
              ))),
              Padding(padding: const EdgeInsets.all(20), child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(children: [
                    Image.asset('assets/images/app_logo.png', width: 54, height: 54, errorBuilder: (context, error, stackTrace) => const Icon(Icons.swap_horiz_rounded, color: Colors.white, size: 48)),
                    const SizedBox(width: 10),
                    const Text('تحويلاتي', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900)),
                  ]),
                  const SizedBox(height: 7),
                  const Text('كل تحويلاتك في مكان واحد', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Text('أسرع.. أسهل.. وأكثر أماناً', style: GoogleFonts.arefRuqaa(color: Colors.white.withValues(alpha: .95), fontSize: 19, fontWeight: FontWeight.w700)),
                ],
              )),
              const Positioned(left: 14, bottom: 12, child: Text('🇵🇸', style: TextStyle(fontSize: 28))),
            ]),
          )),
          const SizedBox(height: 22),
          const Text('اختر خدمة التحويل', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: WalletTile(title: 'جوال باي', subtitle: 'Jawwal Pay', color: green, imagePath: 'assets/images/wallet_jawwal.png', icon: Icons.phone_android_rounded, onTap: () => onWallet('جوال باي'))),
            const SizedBox(width: 9),
            Expanded(child: WalletTile(title: 'بال باي', subtitle: 'PalPay', color: purple, imagePath: 'assets/images/wallet_palpay.png', icon: Icons.account_balance_wallet_rounded, onTap: () => onWallet('بال باي'))),
            const SizedBox(width: 9),
            Expanded(child: WalletTile(title: 'بنك فلسطين', subtitle: 'Bank of Palestine', color: burgundy, imagePath: 'assets/images/wallet_bank.png', icon: Icons.account_balance_rounded, onTap: () => onWallet('بنك فلسطين'))),
          ]),
          const SizedBox(height: 16),
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
            Container(width: 58, height: 58, decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFFFFD66B), Color(0xFFCE8B17)]),
              borderRadius: BorderRadius.circular(19), boxShadow: [BoxShadow(color: Colors.orange.withValues(alpha: .22), blurRadius: 12, offset: const Offset(0, 5))],
            ), child: ClipRRect(borderRadius: BorderRadius.circular(19), child: Image.asset('assets/images/wallet_ussd.png', fit: BoxFit.cover))),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('فحص رصيد جوال باي', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
              SizedBox(height: 3),
              Text(balanceCode, style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
            ])),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 11)),
              onPressed: () => _launchUssd(context, balanceCode, wallet: 'جوال باي', title: 'فحص الرصيد', type: 'balance', onSaved: onSaved),
              child: const Text('اتصال'),
            ),
          ]))),
          const SizedBox(height: 16),
          ClipRRect(borderRadius: BorderRadius.circular(18), child: SizedBox(
            height: 76,
            child: Stack(fit: StackFit.expand, children: [
              Image.asset('assets/images/jerusalem.png', fit: BoxFit.cover),
              Container(color: navy.withValues(alpha: .78)),
              Center(child: Text('فلسطين دائماً في قلوبنا ♡', style: GoogleFonts.arefRuqaa(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w700))),
            ]),
          )),
          const SizedBox(height: 16),
          Row(children: [
            const Icon(Icons.verified_user_outlined, color: green, size: 19),
            const SizedBox(width: 7),
            Expanded(child: Text('تحويلاتي لا تنفّذ التحويل تلقائياً؛ بل تفتح لوحة الاتصال لمراجعة كود USSD وتأكيده.', style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor))),
          ]),
        ]),
      )),
    ]);
  }
}

Widget _circleAction(BuildContext context, IconData icon, VoidCallback onTap) => Material(
  color: Theme.of(context).cardColor, shape: const CircleBorder(),
  child: IconButton(onPressed: onTap, icon: Icon(icon)),
);
class WalletTile extends StatelessWidget {
  final String title, subtitle;
  final Color color;
  final IconData icon;
  final String imagePath;
  final VoidCallback onTap;
  const WalletTile({super.key, required this.title, required this.subtitle, required this.color, required this.icon, required this.imagePath, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap, borderRadius: BorderRadius.circular(22),
    child: Container(height: 128, padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [color, color.withValues(alpha: .78)]),
        borderRadius: BorderRadius.circular(22), boxShadow: [BoxShadow(color: color.withValues(alpha: .2), blurRadius: 12, offset: const Offset(0, 5))]),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Hero(tag: 'wallet-${title}', child: ClipRRect(borderRadius: BorderRadius.circular(13), child: Image.asset(imagePath, width: 48, height: 48, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Icon(icon, color: Colors.white, size: 34)))),
        const SizedBox(height: 8),
        FittedBox(fit: BoxFit.scaleDown, child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900))),
        const SizedBox(height: 2),
        FittedBox(fit: BoxFit.scaleDown, child: Text(subtitle, style: TextStyle(color: Colors.white.withValues(alpha: .85), fontSize: 9))),
      ]),
    ),
  );
}

class WalletPage extends StatefulWidget {
  final String wallet;
  final VoidCallback onSaved;
  const WalletPage({super.key, required this.wallet, required this.onSaved});
  @override
  State<WalletPage> createState() => _WalletPageState();
}
class _WalletPageState extends State<WalletPage> {
  final phone = TextEditingController();
  final amount = TextEditingController();
  final details = TextEditingController();
  String type = 'لصديق';
  Color get accent => widget.wallet == 'جوال باي' ? green : widget.wallet == 'بال باي' ? purple : burgundy;
  String get code => widget.wallet == 'جوال باي'
      ? (type == 'لصديق' ? '*110*1*' : '*110*2*')
      : widget.wallet == 'بال باي'
          ? (type == 'لصديق' ? '*370*1*1*' : '')
          : '*267#';
  @override
  void dispose() { phone.dispose(); amount.dispose(); details.dispose(); super.dispose(); }

  Future<void> submit() async {
    if (widget.wallet == 'بنك فلسطين') {
      await _launchUssd(context, '*267#', wallet: widget.wallet, title: 'فتح قائمة خدمات البنك', type: 'menu', onSaved: widget.onSaved);
      return;
    }
    final number = phone.text.replaceAll(RegExp(r'\D'), '');
    if (!RegExp(r'^05\d{8}$').hasMatch(number)) {
      _message(context, 'أدخل رقم جوال فلسطيني صحيحاً بصيغة 05XXXXXXXX'); return;
    }
    final value = double.tryParse(amount.text.trim().replaceAll(',', '.'));
    if (value == null || value <= 0 || !value.isFinite) {
      _message(context, 'أدخل مبلغاً صحيحاً أكبر من صفر'); return;
    }
    if (widget.wallet == 'بال باي' && type == 'لتاجر') {
      _message(context, 'كود الدفع لتاجر عبر بال باي غير مؤكد حالياً، لذلك لم يتم تفعيله.'); return;
    }
    final cleanAmount = amount.text.trim().replaceAll(',', '.');
    final fullCode = '$code$number*$cleanAmount#';
    await _launchUssd(context, fullCode, wallet: widget.wallet, title: 'تحويل عبر ${widget.wallet} ($type)', phone: number, amount: cleanAmount, details: details.text.trim(), type: type, onSaved: widget.onSaved);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverToBoxAdapter(child: Container(
          height: 180,
          decoration: BoxDecoration(gradient: LinearGradient(colors: [accent, accent.withValues(alpha: .78)]), borderRadius: const BorderRadius.vertical(bottom: Radius.circular(34))),
          child: SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Hero(tag: 'wallet-${widget.wallet}', child: widget.wallet == 'جوال باي' ? Image.asset('assets/images/wallet_jawwal.png', width: 44, height: 44) : widget.wallet == 'بال باي' ? Image.asset('assets/images/wallet_palpay.png', width: 44, height: 44) : Image.asset('assets/images/wallet_bank.png', width: 44, height: 44)),
              const Spacer(),
              Text(widget.wallet, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
              const Spacer(),
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white)),
            ]),
            const Spacer(),
            const Text('تحويل آمن وسريع', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
            const Text('أدخل البيانات ثم راجع كود الاتصال قبل التأكيد', style: TextStyle(color: Colors.white70, fontSize: 12)),
          ])),
        ))),
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          if (widget.wallet != 'بنك فلسطين') ...[
            const Text('نوع العملية', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 9),
            SegmentedButton<String>(
              segments: const [ButtonSegment(value: 'لصديق', label: Text('لصديق'), icon: Icon(Icons.person_outline)), ButtonSegment(value: 'لتاجر', label: Text('لتاجر'), icon: Icon(Icons.storefront_outlined))],
              selected: {type}, onSelectionChanged: (s) => setState(() => type = s.first),
              style: ButtonStyle(visualDensity: VisualDensity.comfortable, shape: WidgetStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)))),
            ),
            const SizedBox(height: 18),
            TextField(controller: phone, keyboardType: TextInputType.phone, inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(10)],
              decoration: const InputDecoration(labelText: 'رقم الجوال', hintText: '05XXXXXXXX', prefixIcon: Icon(Icons.person_outline))),
            const SizedBox(height: 14),
            TextField(controller: details, decoration: const InputDecoration(labelText: 'التفاصيل (اختياري)', hintText: 'ملاحظات عن التحويل', prefixIcon: Icon(Icons.subject_rounded))),
            const SizedBox(height: 14),
            TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))],
              decoration: const InputDecoration(labelText: 'المبلغ', hintText: 'مثال: 200', prefixIcon: Icon(Icons.payments_outlined), suffixText: 'شيكل')),
            const SizedBox(height: 20),
          ] else ...[
            Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
              Icon(Icons.account_balance_rounded, size: 48, color: accent),
              const SizedBox(height: 8),
              const Text('خدمات بنك فلسطين', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
              const Text('سيتم فتح قائمة الخدمات عبر كود USSD الخاص بالبنك'),
              const SizedBox(height: 12),
              Text('*267#', style: TextStyle(color: accent, fontWeight: FontWeight.w900, fontSize: 22)),
            ]))),
            const SizedBox(height: 18),
          ],
          SizedBox(height: 56, child: FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: accent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
            onPressed: submit,
            icon: const Icon(Icons.phone_in_talk_rounded), label: const Text('اتصال', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          )),
          if (widget.wallet == 'جوال باي') ...[
            const SizedBox(height: 18),
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
              Container(width: 52, height: 52, decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFFFD66B), Color(0xFFCE8B17)]), borderRadius: BorderRadius.circular(16)), child: ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.asset('assets/images/wallet_ussd.png', fit: BoxFit.cover))),
              const SizedBox(width: 12),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('فحص الرصيد', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                Text(balanceCode, style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
              ])),
              FilledButton(onPressed: () => _launchUssd(context, balanceCode, wallet: 'جوال باي', title: 'فحص الرصيد', type: 'balance', onSaved: widget.onSaved),
                style: FilledButton.styleFrom(backgroundColor: green), child: const Text('افحص رصيدك')),
            ]))),
          ],
          const SizedBox(height: 20),
          ClipRRect(borderRadius: BorderRadius.circular(22), child: SizedBox(height: 130, child: Stack(fit: StackFit.expand, children: [
            Image.asset('assets/images/jerusalem.png', fit: BoxFit.cover),
            Container(color: accent.withValues(alpha: .68)),
            const Center(child: Text('القدس.. حكاية وطن', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900))),
          ]))),
          const SizedBox(height: 12),
          Text('ملاحظة: الاتصال يفتح لوحة الهاتف لمراجعة كود USSD وإكمال العملية بنفسك.', textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).hintColor, fontSize: 11)),
        ]))),
      ]),
    );
  }
}

Future<void> _launchUssd(BuildContext context, String code, {required String wallet, required String title, String phone = '', String amount = '', String details = '', String type = 'balance', VoidCallback? onSaved}) async {
  final approved = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(
    title: const Text('تأكيد فتح الاتصال'),
    content: Directionality(textDirection: TextDirection.rtl, child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      const Text('كود USSD الذي سيتم فتحه:'),
      SelectableText(code, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: green)),
      const SizedBox(height: 8),
      const Text('لن يتم تنفيذ التحويل إلا بعد إكمال الخطوات وتأكيدها من شركة المحفظة.'),
    ])),
    actions: [
      TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('إلغاء')),
      FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('متابعة')),
    ],
  ));
  if (approved != true) return;
  try {
    final uri = Uri(scheme: 'tel', path: code);
    final launched = await launchUrl(uri);
    if (!launched) throw Exception('تعذر فتح تطبيق الهاتف');
    await LocalStore.instance.add({
      'wallet': wallet, 'title': title, 'phone': phone, 'amount': amount, 'details': details,
      'code': code, 'createdAt': DateTime.now().toIso8601String(), 'type': type,
    });
    onSaved?.call();
  } catch (e) {
    if (context.mounted) _message(context, 'لم نتمكن من فتح لوحة الاتصال. تأكد من وجود تطبيق هاتف يدعم USSD.');
  }
}

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}
class _HistoryPageState extends State<HistoryPage> {
  String filter = 'الكل';
  late Future<List<Map<String, Object?>>> future;
  int shown = 10;
  @override
  void initState() { super.initState(); future = LocalStore.instance.all(); }
  void reload() => setState(() => future = LocalStore.instance.all());
  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String, Object?>>>(
    future: future,
    builder: (context, snapshot) {
      final all = snapshot.data ?? [];
      final filtered = all.where((r) => filter == 'الكل' || r['wallet'] == filter).toList();
      final rows = filtered.take(shown).toList();
      return RefreshIndicator(onRefresh: () async => reload(), child: CustomScrollView(slivers: [
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(18, 18, 18, 10), child: Row(children: [
          const Icon(Icons.history_rounded, size: 28, color: Color(0xFF1684E8)),
          const SizedBox(width: 10),
          const Text('سجل الحركات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const Spacer(),
          IconButton(onPressed: () async {
            final yes = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('مسح السجل؟'), content: const Text('سيتم حذف جميع الحركات المحفوظة محلياً.'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف'))]));
            if (yes == true) { await LocalStore.instance.clear(); reload(); }
          }, icon: const Icon(Icons.delete_outline)),
        ]))),
        SliverToBoxAdapter(child: SizedBox(height: 54, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
          for (final item in ['الكل', 'جوال باي', 'بال باي', 'بنك فلسطين'])
            Padding(padding: const EdgeInsetsDirectional.only(end: 8), child: ChoiceChip(label: Text(item), selected: filter == item, onSelected: (_) => setState(() => filter = item))),
        ]))),
        if (snapshot.connectionState == ConnectionState.waiting)
          const SliverFillRemaining(child: Center(child: CircularProgressIndicator()))
        else if (rows.isEmpty)
          const SliverFillRemaining(hasScrollBody: false, child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.receipt_long_outlined, size: 58, color: Colors.grey), SizedBox(height: 10), Text('لا توجد حركات مسجلة بعد', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.w700))])))
        else
          SliverPadding(padding: const EdgeInsets.fromLTRB(16, 10, 16, 18), sliver: SliverList(delegate: SliverChildBuilderDelegate((context, i) {
            final row = rows[i];
            final wallet = row['wallet'] as String;
            final color = wallet == 'جوال باي' ? green : wallet == 'بال باي' ? purple : burgundy;
            final date = DateTime.tryParse(row['createdAt'] as String? ?? '') ?? DateTime.now();
            final dateText = '${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')} • ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
            final isBalance = row['type'] == 'balance';
            return Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              leading: CircleAvatar(
                backgroundColor: color.withValues(alpha: .14),
                child: isBalance
                    ? const Icon(Icons.phone_android, color: Colors.grey)
                    : ClipOval(child: Image.asset(
                        wallet == 'جوال باي' ? 'assets/images/wallet_jawwal.png' : wallet == 'بال باي' ? 'assets/images/wallet_palpay.png' : 'assets/images/wallet_bank.png',
                        width: 42, height: 42, fit: BoxFit.cover,
                      )),
              ),
              title: Text(row['title'] as String? ?? 'عملية', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
              subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(isBalance ? (row['code'] as String? ?? balanceCode) : '$wallet • ${row['phone'] ?? ''}', style: const TextStyle(fontSize: 11)),
                Text(dateText, style: const TextStyle(fontSize: 10, color: Colors.grey)),
              ]),
              trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(isBalance ? 'فحص رصيد' : '+${row['amount']} ₪', style: TextStyle(color: isBalance ? Colors.grey : green, fontWeight: FontWeight.w900, fontSize: 13)),
                const Icon(Icons.chevron_left, size: 18),
              ]),
            ));
          }, childCount: rows.length))),
        if (rows.length < filtered.length)
          SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(18, 0, 18, 28), child: OutlinedButton(onPressed: () => setState(() => shown += 10), child: const Text('عرض المزيد')))),
      ]));
    },
  );
}

class MorePage extends StatelessWidget {
  final ThemeMode mode;
  final ValueChanged<ThemeMode> onModeChanged;
  const MorePage({super.key, required this.mode, required this.onModeChanged});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(18), children: [
      const SizedBox(height: 12),
      const Text('المزيد', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
      const SizedBox(height: 18),
      Card(child: Column(children: [
        const ListTile(leading: Icon(Icons.palette_outlined), title: Text('المظهر'), subtitle: Text('اختر الوضع المناسب أو اتبع إعدادات النظام')),
        RadioListTile<ThemeMode>(value: ThemeMode.system, groupValue: mode, onChanged: (v) => onModeChanged(v!), title: const Text('تلقائي حسب النظام')),
        RadioListTile<ThemeMode>(value: ThemeMode.light, groupValue: mode, onChanged: (v) => onModeChanged(v!), title: const Text('الوضع الفاتح')),
        RadioListTile<ThemeMode>(value: ThemeMode.dark, groupValue: mode, onChanged: (v) => onModeChanged(v!), title: const Text('الوضع الداكن')),
      ])),
      Card(child: const Column(children: [
        ListTile(leading: Icon(Icons.language), title: Text('اللغة'), subtitle: Text('العربية')),
        Divider(height: 1),
        ListTile(leading: Icon(Icons.info_outline), title: Text('عن التطبيق'), subtitle: Text('تحويلاتي – كل تحويلاتك في مكان واحد')),
      ])),
      const SizedBox(height: 22),
      Center(child: Column(children: [
        Image.asset('assets/images/app_logo.png', width: 82, height: 82),
        const SizedBox(height: 8),
        const Text('تحويلاتي', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
        const Text('الإصدار 2.0.0 • Flutter', style: TextStyle(color: Colors.grey)),
        const SizedBox(height: 5),
        const Text('برمجة وتصميم م. لؤي النواجحة', style: TextStyle(color: Colors.grey, fontSize: 12)),
      ])),
    ]);
  }
}

void _message(BuildContext context, String text) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), behavior: SnackBarBehavior.floating));
}
