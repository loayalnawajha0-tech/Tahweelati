package com.loay.tahweelati

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Teal = Color(0xFF159C91)
private val Navy = Color(0xFF102A36)

@Serializable
data class Transfer(
    val id: Long,
    val wallet: String,
    val kind: String,
    val recipient: String,
    val amount: String,
    val note: String,
    val date: String,
    val code: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("tahweelati", MODE_PRIVATE)
        setContent {
            var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
            val scheme = if (dark) darkColorScheme(
                primary = Color(0xFF45C4B5), secondary = Color(0xFFD5B56A),
                background = Navy, surface = Color(0xFF193744),
                onSurface = Color(0xFFF2F7F6), onBackground = Color(0xFFF2F7F6)
            ) else lightColorScheme(
                primary = Color(0xFF168F88), secondary = Color(0xFFC49B45),
                background = Color(0xFFF4F8F7), surface = Color.White,
                onSurface = Color(0xFF19343D), onBackground = Color(0xFF19343D)
            )
            MaterialTheme(colorScheme = scheme) {
                TahweelatiApp(
                    dark = dark,
                    onDarkChange = { dark = it; prefs.edit().putBoolean("dark", it).apply() },
                    loadTransfers = {
                        runCatching { Json.decodeFromString<List<Transfer>>(prefs.getString("history", "[]") ?: "[]") }
                            .getOrDefault(emptyList())
                    },
                    saveTransfers = { prefs.edit().putString("history", Json.encodeToString(it)).apply() }
                )
            }
        }
    }
}

private fun buildUssd(wallet: String, kind: String, phone: String, amount: String): String? {
    val prefix = when (wallet to kind) {
        "جوال باي" to "لصديق" -> "*110*1*"
        "جوال باي" to "لتاجر" -> "*110*2*"
        "بال باي" to "لصديق" -> "*370*1*1*"
        // PalPay merchant code was not confirmed by the user; intentionally disabled.
        else -> return null
    }
    return "$prefix$phone*$amount#"
}

@Composable
fun TahweelatiApp(
    dark: Boolean,
    onDarkChange: (Boolean) -> Unit,
    loadTransfers: () -> List<Transfer>,
    saveTransfers: (List<Transfer>) -> Unit
) {
    val context = LocalContext.current
    var wallet by remember { mutableStateOf("جوال باي") }
    var kind by remember { mutableStateOf("لصديق") }
    var recipient by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var transfers by remember { mutableStateOf(loadTransfers()) }
    var tab by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf("") }
    var pendingCode by remember { mutableStateOf<String?>(null) }
    var isBankMenu by remember { mutableStateOf(false) }

    fun validateAndPrepare() {
        error = ""
        if (wallet == "بنك فلسطين") {
            isBankMenu = true
            pendingCode = "*267#"
            return
        }
        if (wallet == "بال باي" && kind == "لتاجر") {
            error = "كود بال باي للدفع لتاجر غير مؤكد، لذلك تم تعطيل هذا الخيار حتى تزويدنا بالكود الرسمي."
            return
        }
        val cleanPhone = recipient.filter { it.isDigit() }
        if (cleanPhone.length != 10 || !cleanPhone.startsWith("05")) {
            error = "أدخل رقم جوال فلسطيني صحيحاً بصيغة 05XXXXXXXX."
            return
        }
        val parsedAmount = amount.trim().replace(',', '.').toBigDecimalOrNull()
        if (parsedAmount == null || parsedAmount <= java.math.BigDecimal.ZERO) {
            error = "المبلغ إلزامي ويجب أن يكون أكبر من صفر."
            return
        }
        val normalizedAmount = parsedAmount.stripTrailingZeros().toPlainString()
        val code = buildUssd(wallet, kind, cleanPhone, normalizedAmount)
        if (code == null) {
            error = "صيغة هذا التحويل غير متاحة حالياً."
            return
        }
        isBankMenu = false
        pendingCode = code
    }

    fun openDialer(code: String) {
        val date = SimpleDateFormat("yyyy/MM/dd - HH:mm:ss", Locale.getDefault()).format(Date())
        if (!isBankMenu) {
            val item = Transfer(
                id = System.currentTimeMillis(), wallet = wallet, kind = kind,
                recipient = recipient.filter { it.isDigit() }, amount = amount.trim(),
                note = note.trim(), date = date, code = code
            )
            transfers = listOf(item) + transfers
            saveTransfers(transfers)
        }
        val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", code, null))
        context.startActivity(intent)
        pendingCode = null
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.SwapHoriz, null) }, label = { Text("تحويل جديد") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.History, null) }, label = { Text("السجل") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.Settings, null) }, label = { Text("الإعدادات") })
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            Header(dark)
            when (tab) {
                0 -> {
                    Text("تحويل جديد", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("اختر الخدمة وأدخل بيانات التحويل", fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                    Spacer(Modifier.height(12.dp))
                    CardBlock {
                        Text("1. نوع الدفع", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("لصديق", "لتاجر").forEach { option ->
                                FilterChip(selected = kind == option, onClick = { kind = option; error = "" },
                                    label = { Text(option) })
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("2. اختر المحفظة", fontWeight = FontWeight.Bold)
                        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("جوال باي", "بال باي", "بنك فلسطين").forEach { option ->
                                WalletChoice(option, wallet == option) { wallet = option; error = "" }
                            }
                        }
                        if (wallet == "بنك فلسطين") {
                            Spacer(Modifier.height(8.dp))
                            Text("سيتم فتح قائمة خدمات بنك فلسطين عبر الكود *267#.",
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        } else {
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = recipient, onValueChange = { recipient = it.filter { c -> c.isDigit() || c == '+' }.take(13); error = "" },
                                modifier = Modifier.fillMaxWidth(), label = { Text("3. رقم الجوال (إلزامي)") },
                                placeholder = { Text("05XXXXXXXX") }, leadingIcon = { Icon(Icons.Default.Phone, null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true
                            )
                            Spacer(Modifier.height(9.dp))
                            OutlinedTextField(
                                value = amount, onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' || c == ',' }; error = "" },
                                modifier = Modifier.fillMaxWidth(), label = { Text("4. المبلغ بالشيكل (إلزامي)") },
                                placeholder = { Text("مثال: 100") }, leadingIcon = { Icon(Icons.Default.Payments, null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true
                            )
                            Spacer(Modifier.height(9.dp))
                            OutlinedTextField(value = note, onValueChange = { note = it },
                                modifier = Modifier.fillMaxWidth(), label = { Text("5. ملاحظات (اختياري)") },
                                leadingIcon = { Icon(Icons.Default.EditNote, null) }, minLines = 2)
                        }
                        if (wallet == "بال باي" && kind == "لتاجر") {
                            Text("كود الدفع لتاجر غير مؤكد حالياً", color = MaterialTheme.colorScheme.error,
                                fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        if (error.isNotBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { validateAndPrepare() }, modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(16.dp)) {
                            Icon(Icons.Default.Dialpad, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (wallet == "بنك فلسطين") "فتح قائمة USSD" else "إنشاء الكود والاتصال", fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Text("لن يتم تنفيذ التحويل تلقائياً. ستفتح لوحة الاتصال لتراجع الكود وتكمل العملية بنفسك.",
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                }
                1 -> {
                    Text("سجل الحركات", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("ابحث برقم الجوال أو المحفظة أو الملاحظات") },
                        leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                    Spacer(Modifier.height(10.dp))
                    val filtered = transfers.filter { listOf(it.wallet, it.recipient, it.amount, it.note).any { s -> s.contains(search, true) } }
                    if (filtered.isEmpty()) EmptyHistory() else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered, key = { it.id }) { item ->
                            CardBlock {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.wallet, fontWeight = FontWeight.Bold)
                                        Text("${item.kind} • ${item.recipient}", fontSize = 12.sp)
                                        Text("${item.amount} ₪  |  ${item.date}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                        Text("تم فتح لوحة الاتصال — غير مؤكد الإتمام", fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
                                        if (item.note.isNotBlank()) Text(item.note, fontSize = 11.sp)
                                    }
                                    IconButton(onClick = { transfers = transfers.filterNot { it.id == item.id }; saveTransfers(transfers) }) {
                                        Icon(Icons.Default.DeleteOutline, "حذف")
                                    }
                                }
                            }
                        }
                    }
                }
                else -> {
                    Text("الإعدادات", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    CardBlock {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("المظهر", fontWeight = FontWeight.Bold)
                                Text("التبديل بين الوضع الداكن والنهاري", fontSize = 12.sp)
                            }
                            Switch(checked = dark, onCheckedChange = onDarkChange)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    CardBlock {
                        Text("الأكواد المضافة", fontWeight = FontWeight.Bold)
                        Text("جوال باي — لصديق: *110*1*رقم*مبلغ#", fontSize = 12.sp)
                        Text("جوال باي — لتاجر: *110*2*رقم*مبلغ#", fontSize = 12.sp)
                        Text("بال باي — لصديق: *370*1*1*رقم*مبلغ#", fontSize = 12.sp)
                        Text("بال باي — لتاجر: غير مفعّل حتى تأكيد الكود", fontSize = 12.sp)
                        Text("بنك فلسطين — قائمة USSD: *267#", fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    CardBlock {
                        Text("حول التطبيق", fontWeight = FontWeight.Bold)
                        Text("تحويلاتي", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        Text("برمجة وتصميم م.لؤي النواجحة", fontWeight = FontWeight.Medium)
                        Text("الإصدار 1.1", fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("برمجة وتصميم م.لؤي النواجحة", modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center, fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
            Spacer(Modifier.height(6.dp))
        }
    }

    if (pendingCode != null) {
        AlertDialog(
            onDismissRequest = { pendingCode = null },
            title = { Text(if (isBankMenu) "قائمة بنك فلسطين" else "مراجعة كود التحويل") },
            text = {
                Column {
                    Text(if (isBankMenu) "سيتم فتح لوحة الاتصال بالكود التالي:" else "راجع بياناتك والكود قبل الانتقال إلى لوحة الاتصال:")
                    Spacer(Modifier.height(10.dp))
                    Surface(color = MaterialTheme.colorScheme.background, shape = RoundedCornerShape(12.dp)) {
                        Text(pendingCode ?: "", modifier = Modifier.fillMaxWidth().padding(14.dp),
                            textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    if (!isBankMenu) Text("تأكد من رقم المستلم والمبلغ. لا تؤكد أي عملية لا تعرفها.", fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { openDialer(pendingCode!!) }) { Text("فتح الاتصال") } },
            dismissButton = { TextButton(onClick = { pendingCode = null }) { Text("رجوع") } }
        )
    }
}

@Composable
fun Header(dark: Boolean) {
    Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(15.dp), color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(46.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.AccountBalanceWallet, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("تحويلاتي", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
            Text("إدارة تحويلاتك بسهولة وأمان", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
        }
        Icon(if (dark) Icons.Default.DarkMode else Icons.Default.LightMode, null, tint = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun CardBlock(content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), content = content)
    }
}

@Composable
fun WalletChoice(name: String, selected: Boolean, onClick: () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth().clickable { onClick() }, shape = RoundedCornerShape(13.dp),
        color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = .12f) else MaterialTheme.colorScheme.background,
        border = if (selected) androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AccountBalance, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Text(name, Modifier.weight(1f), fontWeight = FontWeight.Medium)
            if (selected) Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun EmptyHistory() {
    Column(Modifier.fillMaxWidth().padding(vertical = 45.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.ReceiptLong, null, modifier = Modifier.size(46.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = .7f))
        Spacer(Modifier.height(8.dp))
        Text("لا توجد حركات محفوظة بعد", fontWeight = FontWeight.SemiBold)
        Text("ستظهر هنا العمليات التي فتحت لها لوحة الاتصال", fontSize = 12.sp)
    }
}
