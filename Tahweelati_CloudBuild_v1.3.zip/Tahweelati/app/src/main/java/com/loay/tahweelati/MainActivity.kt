package com.loay.tahweelati

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Teal = Color(0xFF12B8F3)
private val Navy = Color(0xFF071333)
private val Panel = Color(0xFF101F4A)
private val ElectricBlue = Color(0xFF087BFF)
private val Violet = Color(0xFF792BFF)

@Serializable
data class Transfer(
    val id: Long,
    val wallet: String,
    val kind: String,
    val recipient: String,
    val amount: String,
    val note: String,
    val date: String,
    val code: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("tahweelati", MODE_PRIVATE)
        setContent {
            var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
            var english by remember { mutableStateOf(prefs.getBoolean("english", false)) }
            val scheme = if (dark) darkColorScheme(
                primary = Color(0xFF19B9FF), secondary = Color(0xFF9B5CFF),
                background = Navy, surface = Panel,
                onSurface = Color(0xFFF4F7FF), onBackground = Color(0xFFF4F7FF)
            ) else lightColorScheme(
                primary = Color(0xFF087BFF), secondary = Color(0xFF792BFF),
                background = Color(0xFFF4F8F7), surface = Color.White,
                onSurface = Color(0xFF19343D), onBackground = Color(0xFF19343D)
            )
            MaterialTheme(colorScheme = scheme) {
                TahweelatiApp(
                    dark = dark,
                    english = english,
                    onEnglishChange = { english = it; prefs.edit().putBoolean("english", it).apply() },
                    onDarkChange = { dark = it; prefs.edit().putBoolean("dark", it).apply() },
                    loadTransfers = {
                        runCatching { Json.decodeFromString<List<Transfer>>(prefs.getString("history", "[]") ?: "[]") }
                            .getOrDefault(emptyList())
                    },
                    saveTransfers = { prefs.edit().putString("history", Json.encodeToString(it)).apply() }
                )
            }
        }
    }
}

private fun buildUssd(wallet: String, kind: String, phone: String, amount: String): String? {
    val prefix = when (wallet to kind) {
        "جوال باي" to "لصديق" -> "*110*1*"
        "جوال باي" to "لتاجر" -> "*110*2*"
        "بال باي" to "لصديق" -> "*370*1*1*"
        "بال باي" to "لتاجر" -> "*370*1*2*"
        else -> return null
    }
    return "$prefix$phone*$amount#"
}

@Composable
fun TahweelatiApp(
    dark: Boolean,
    english: Boolean,
    onEnglishChange: (Boolean) -> Unit,
    onDarkChange: (Boolean) -> Unit,
    loadTransfers: () -> List<Transfer>,
    saveTransfers: (List<Transfer>) -> Unit
) {
    val context = LocalContext.current
    var wallet by remember { mutableStateOf("جوال باي") }
    var kind by remember { mutableStateOf("لصديق") }
    var recipient by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var transfers by remember { mutableStateOf(loadTransfers()) }
    var tab by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf("") }
    var pendingCode by remember { mutableStateOf<String?>(null) }
    var isBankMenu by remember { mutableStateOf(false) }
    var isBalanceCheck by remember { mutableStateOf(false) }
    var historyFilter by remember { mutableStateOf("الكل") }
    fun tr(ar: String, en: String) = if (english) en else ar

    fun validateAndPrepare() {
        error = ""
        if (wallet == "بنك فلسطين") {
            isBankMenu = true
            pendingCode = "*267#"
            return
        }
        val cleanPhone = recipient.filter { it.isDigit() }
        if (cleanPhone.length != 10 || !cleanPhone.startsWith("05")) {
            error = if (english) "Enter a valid Palestinian mobile number (05XXXXXXXX)." else "أدخل رقم جوال فلسطيني صحيحاً بصيغة 05XXXXXXXX."
            return
        }
        val parsedAmount = amount.trim().replace(',', '.').toBigDecimalOrNull()
        if (parsedAmount == null || parsedAmount <= java.math.BigDecimal.ZERO) {
            error = if (english) "Amount is required and must be greater than zero." else "المبلغ إلزامي ويجب أن يكون أكبر من صفر."
            return
        }
        val normalizedAmount = parsedAmount.stripTrailingZeros().toPlainString()
        val code = buildUssd(wallet, kind, cleanPhone, normalizedAmount)
        if (code == null) {
            error = if (english) "This transfer type is currently unavailable." else "صيغة هذا التحويل غير متاحة حالياً."
            return
        }
        isBankMenu = false
        pendingCode = code
    }

    fun prepareBalanceCheck() {
        isBalanceCheck = true
        isBankMenu = false
        pendingCode = "*268*3#"
    }

    fun openDialer(code: String) {
        val date = SimpleDateFormat("yyyy/MM/dd - HH:mm:ss", Locale.getDefault()).format(Date())
        if (!isBankMenu && !isBalanceCheck) {
            val item = Transfer(
                id = System.currentTimeMillis(), wallet = wallet, kind = kind,
                recipient = recipient.filter { it.isDigit() }, amount = amount.trim(),
                note = note.trim(), date = date, code = code
            )
            transfers = listOf(item) + transfers
            saveTransfers(transfers)
        }
        val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", code, null))
        context.startActivity(intent)
        pendingCode = null
        isBalanceCheck = false
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Home, null) }, label = { Text(tr("الرئيسية", "Home")) })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.History, null) }, label = { Text(tr("السجل", "History")) })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.SwapHoriz, null) }, label = { Text(tr("تحويل", "Transfer")) })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 },
                    icon = { Icon(Icons.Default.Settings, null) }, label = { Text(tr("الإعدادات", "Settings")) })
            }
        }
    ) { padding ->
        val scrollState = rememberScrollState()
        Column(
            Modifier.fillMaxSize().padding(padding).imePadding()
                .then(if (tab != 1) Modifier.verticalScroll(scrollState) else Modifier)
                .padding(horizontal = 16.dp)
        ) {
            Header(dark)
            when (tab) {
                0 -> {
                    HomeDashboard(english = english, onTransfer = { selected -> wallet = selected; tab = 2 }, onHistory = { tab = 1 })
                }
                2 -> {
                    Text(tr("تحويل جديد", "New transfer"), fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text(tr("اختر الخدمة وأدخل بيانات التحويل", "Choose a service and enter transfer details"), fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                    Spacer(Modifier.height(12.dp))
                    CardBlock {
                        Text(tr("1. نوع الدفع", "1. Payment type"), fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("لصديق", "لتاجر").forEach { option ->
                                FilterChip(selected = kind == option, onClick = { kind = option; error = "" },
                                    label = { Text(if (english) if (option == "لصديق") "To friend" else "To merchant" else option) })
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(tr("2. اختر المحفظة", "2. Choose wallet"), fontWeight = FontWeight.Bold)
                        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("جوال باي", "بال باي", "بنك فلسطين").forEach { option ->
                                WalletChoice(option, wallet == option, english) { wallet = option; error = "" }
                            }
                        }
                        if (wallet == "بنك فلسطين") {
                            Spacer(Modifier.height(8.dp))
                            Text("سيتم فتح قائمة خدمات بنك فلسطين.",
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        } else {
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = recipient, onValueChange = { recipient = it.filter { c -> c.isDigit() || c == '+' }.take(13); error = "" },
                                modifier = Modifier.fillMaxWidth(), label = { Text(tr("3. رقم الجوال", "3. Phone number")) },
                                placeholder = { Text("05XXXXXXXX") }, leadingIcon = { Icon(Icons.Default.Phone, null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true
                            )
                            Spacer(Modifier.height(9.dp))
                            OutlinedTextField(
                                value = amount, onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' || c == ',' }; error = "" },
                                modifier = Modifier.fillMaxWidth(), label = { Text(tr("4. المبلغ بالشيكل", "4. Amount in ILS")) },
                                placeholder = { Text("مثال: 100") }, leadingIcon = { Icon(Icons.Default.Payments, null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true
                            )
                            Spacer(Modifier.height(9.dp))
                            OutlinedTextField(value = note, onValueChange = { note = it },
                                modifier = Modifier.fillMaxWidth(), label = { Text(tr("5. ملاحظات (اختياري)", "5. Notes (optional)")) },
                                leadingIcon = { Icon(Icons.Default.EditNote, null) }, minLines = 2)
                        }
                        if (error.isNotBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { validateAndPrepare() }, modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087BFF))) {
                            Icon(Icons.Default.Dialpad, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (wallet == "بنك فلسطين") "فتح قائمة USSD" else "إنشاء الكود والاتصال", fontWeight = FontWeight.Bold)
                        }
                    }
                    if (wallet == "جوال باي") {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { prepareBalanceCheck() }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                            Icon(Icons.Default.AccountBalanceWallet, null)
                            Spacer(Modifier.width(8.dp))
                            Text(tr("فحص رصيد جوال بي", "Check Jawwal Pay balance"))
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Text(tr("لن يتم تنفيذ التحويل تلقائياً. ستفتح لوحة الاتصال لتراجع العملية وتكملها بنفسك.", "The transfer is not automatic. The dialer opens so you can review and complete it yourself."),
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                }
                1 -> {
                    Text(tr("سجل الحركات", "Transaction history"), fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text(tr("ابحث برقم الجوال أو المحفظة أو الملاحظات", "Search phone, wallet or notes")) },
                        leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                        listOf("الكل", "جوال باي", "بال باي", "بنك فلسطين").forEach { f ->
                            FilterChip(
                                selected = historyFilter == f,
                                onClick = { historyFilter = f },
                                label = { Text(when (f) {
                                    "الكل" -> tr("الكل", "All")
                                    "جوال باي" -> "Jawwal Pay"
                                    "بال باي" -> "PalPay"
                                    else -> tr("بنك فلسطين", "Bank of Palestine")
                                }, fontSize = 11.sp) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    val filtered = transfers
                        .filter { historyFilter == "الكل" || it.wallet == historyFilter }
                        .filter { listOf(it.wallet, it.recipient, it.amount, it.note).any { v -> v.contains(search, true) } }
                        .sortedByDescending { it.id }
                    if (filtered.isEmpty()) EmptyHistory() else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered, key = { it.id }) { item ->
                            CardBlock {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.wallet, fontWeight = FontWeight.Bold)
                                        Text("${if (english) if (item.kind == "لصديق") "To friend" else "To merchant" else item.kind} • ${item.recipient}", fontSize = 12.sp)
                                        Text("${item.amount} ₪  |  ${item.date}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                        Text("تم فتح لوحة الاتصال — غير مؤكد الإتمام", fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
                                        if (item.note.isNotBlank()) Text(item.note, fontSize = 11.sp)
                                    }
                                    IconButton(onClick = { transfers = transfers.filterNot { it.id == item.id }; saveTransfers(transfers) }) {
                                        Icon(Icons.Default.DeleteOutline, "حذف")
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> {
                    Text(tr("الإعدادات", "Settings"), fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    CardBlock {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tr("المظهر", "Appearance"), fontWeight = FontWeight.Bold)
                                Text(tr("التبديل بين الوضع الداكن والنهاري", "Switch between dark and light mode"), fontSize = 12.sp)
                            }
                            Switch(checked = dark, onCheckedChange = onDarkChange)
                        }
                    }
                    CardBlock {
                        Text(tr("اللغة", "Language"), fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = !english, onClick = { onEnglishChange(false) }, label = { Text("العربية") })
                            FilterChip(selected = english, onClick = { onEnglishChange(true) }, label = { Text("English") })
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    CardBlock {
                        Text(tr("حول التطبيق", "About the app"), fontWeight = FontWeight.Bold)
                        Text("تحويلاتي", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        Text("تصميم وبرمجة م.لؤي النواجحة", fontWeight = FontWeight.Bold)
                        Text("Eng: Loay Alnawajha", fontWeight = FontWeight.Bold)
                        Text("الإصدار 1.2", fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            DeveloperCard()
            Spacer(Modifier.height(16.dp))
        }
    }

    if (pendingCode != null) {
        AlertDialog(
            onDismissRequest = { pendingCode = null },
            title = { Text(if (isBalanceCheck) tr("فحص رصيد جوال بي", "Jawwal Pay balance") else if (isBankMenu) tr("بنك فلسطين", "Bank of Palestine") else tr("مراجعة التحويل", "Review transfer")) },
            text = {
                Column {
                    if (isBalanceCheck) {
                        Text(tr("سيتم فتح الاتصال بكود فحص الرصيد *268*3#", "The dialer will open with balance code *268*3#"))
                    } else if (isBankMenu) {
                        Text(tr("سيتم فتح قائمة خدمات بنك فلسطين.", "The Bank of Palestine services menu will open."))
                    } else {
                        Text("راجع بياناتك قبل الانتقال إلى لوحة الاتصال:")
                        Spacer(Modifier.height(10.dp))
                        Surface(color = MaterialTheme.colorScheme.background, shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                Text("المحفظة: $wallet", fontWeight = FontWeight.Bold)
                                Text("النوع: $kind")
                                Text("الرقم: ${recipient.filter { it.isDigit() }}")
                                Text("المبلغ: ${amount.trim()} ₪", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { openDialer(pendingCode!!) }) { Text(tr("اتصال", "Call")) } },
            dismissButton = { TextButton(onClick = { pendingCode = null }) { Text(tr("رجوع", "Back")) } }
        )
    }
}

@Composable
fun HomeDashboard(english: Boolean, onTransfer: (String) -> Unit, onHistory: () -> Unit) {
    fun label(ar: String, en: String) = if (english) en else ar
    Spacer(Modifier.height(8.dp))
    Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF063D91), Color(0xFF21116D), Color(0xFF101B48))))
            .padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label("مرحباً بك", "Welcome"), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text(label("في تطبيق تحويلاتي", "to Tahweelati"), color = Color(0xFFB8DFFF), fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                Text(label("كل تحويلاتك في مكان واحد", "All your transfers in one place"), color = Color.White, fontSize = 12.sp)
            }
            Image(painter = painterResource(id = R.drawable.app_logo), contentDescription = "Tahweelati",
                modifier = Modifier.size(86.dp), contentScale = ContentScale.Fit)
        }
    }
    Spacer(Modifier.height(16.dp))
    Text(label("اختر محفظتك", "Choose your wallet"), fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Text(label("ابدأ التحويل بخطوات بسيطة", "Start a transfer in a few simple steps"), fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        WalletHomeTile("جوال باي", R.drawable.wallet_jawwal, Color(0xFF8BCB36), english, Modifier.weight(1f)) { onTransfer("جوال باي") }
        WalletHomeTile("بال باي", R.drawable.wallet_palpay, Color(0xFF8A35B7), english, Modifier.weight(1f)) { onTransfer("بال باي") }
        WalletHomeTile("بنك فلسطين", R.drawable.wallet_bop, Color(0xFFB31E70), english, Modifier.weight(1f)) { onTransfer("بنك فلسطين") }
    }
    Spacer(Modifier.height(15.dp))
    CardBlock {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label("تحويل جديد", "New transfer"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(label("اختر نوع الدفع وأدخل بيانات المستلم", "Select payment type and recipient details"), fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
            }
            Icon(Icons.Default.Send, null, tint = Color(0xFF12B8F3), modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { onTransfer("جوال باي") }, modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(15.dp)) {
            Text(label("ابدأ التحويل الآن", "Start transfer"), fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, null)
        }
    }
    Spacer(Modifier.height(12.dp))
    OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(15.dp)) {
        Icon(Icons.Default.History, null); Spacer(Modifier.width(8.dp)); Text(label("عرض سجل التحويلات", "View transaction history"))
    }
    Spacer(Modifier.height(8.dp))
    Text(label("ملاحظة: التطبيق يفتح لوحة الاتصال لمراجعة كود USSD وإكمال العملية بنفسك.",
        "Note: the app opens the dialer so you can review the USSD code and complete the transaction."),
        fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f), textAlign = TextAlign.Center)
}

@Composable
fun WalletHomeTile(name: String, logo: Int, tint: Color, english: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(modifier = modifier.height(126.dp).clickable { onClick() }, shape = RoundedCornerShape(19.dp),
        color = tint.copy(alpha = if (MaterialTheme.colorScheme.background == Color.White) .10f else .20f),
        border = androidx.compose.foundation.BorderStroke(1.dp, tint.copy(alpha = .7f))) {
        Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Image(painter = painterResource(logo), contentDescription = name, modifier = Modifier.size(48.dp), contentScale = ContentScale.Fit)
            Spacer(Modifier.height(7.dp))
            Text(if (english) when (name) { "جوال باي" -> "Jawwal Pay"; "بال باي" -> "PalPay"; else -> "Bank of Palestine" } else name,
                fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}

@Composable
fun Header(dark: Boolean) {
    Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Image(painter = painterResource(id = R.drawable.app_logo), contentDescription = "شعار تحويلاتي",
            modifier = Modifier.size(58.dp), contentScale = ContentScale.Fit)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("تحويلاتي", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold,
                color = if (dark) Color.White else Color(0xFF15334A))
            Text(if (dark) "TAHWEELATI  •  محفظتك لإدارة التحويلات" else "TAHWEELATI  •  Smart Transfers",
                fontSize = 10.sp, color = if (dark) Color(0xFF8ECFFF) else Color(0xFF39718D))
            Text("م.لؤي النواجحة", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                color = if (dark) Color(0xFF42E6D0) else Color(0xFF087B75))
        }
        Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFF14265A)) {
            Icon(if (dark) Icons.Default.DarkMode else Icons.Default.LightMode, null,
                tint = Color(0xFF27C5FF), modifier = Modifier.padding(11.dp))
        }
    }
}

@Composable
fun HeroBanner() {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier.fillMaxWidth().padding(bottom = 15.dp)) {
        Row(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF064B9D), Color(0xFF25116C), Color(0xFF101C4A))))
            .padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("تحويلاتك أسهل وأسرع", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text("اختر محفظتك، أدخل البيانات، وراجع كود الاتصال قبل التأكيد", color = Color(0xFFB9D9FF), fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VerifiedUser, null, tint = Color(0xFF42E6D0), modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("تحكم كامل قبل تنفيذ أي عملية", color = Color(0xFF9CEDE5), fontSize = 10.sp)
                }
            }
            Image(painter = painterResource(id = R.drawable.app_logo), contentDescription = null,
                modifier = Modifier.size(100.dp), contentScale = ContentScale.Fit)
        }
    }
}

@Composable
fun CardBlock(content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(21.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF243D79)),
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), content = content)
    }
}

@Composable
fun WalletChoice(name: String, selected: Boolean, english: Boolean = false, onClick: () -> Unit) {
    val tint = when (name) { "جوال باي" -> Color(0xFF22C55E); "بال باي" -> Color(0xFFB65CFF); else -> Color(0xFFFF3E9D) }
    val logo = when (name) {
        "جوال باي" -> R.drawable.wallet_jawwal
        "بال باي" -> R.drawable.wallet_palpay
        else -> R.drawable.wallet_bop
    }
    Surface(modifier = Modifier.fillMaxWidth().clickable { onClick() }, shape = RoundedCornerShape(15.dp),
        color = if (selected) tint.copy(alpha = .18f) else MaterialTheme.colorScheme.background,
        border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 1.dp, if (selected) tint else Color(0xFF263B70))) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painter = painterResource(id = logo), contentDescription = name,
                modifier = Modifier.size(48.dp), contentScale = ContentScale.Fit)
            Spacer(Modifier.width(12.dp))
            Text(if (english) when (name) {
                "جوال باي" -> "Jawwal Pay"
                "بال باي" -> "PalPay"
                else -> "Bank of Palestine"
            } else name, Modifier.weight(1f), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            if (selected) Icon(Icons.Default.CheckCircle, null, tint = tint)
        }
    }
}

@Composable
fun DeveloperCard() {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier.fillMaxWidth()) {
        Column(
            Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(Color(0xFF064B9D), Color(0xFF25116C))))
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("تطوير وتصميم", fontSize = 11.sp, color = Color(0xFFB9D9FF))
            Text("م.لؤي النواجحة", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("Eng: Loay Alnawajha", fontSize = 11.sp, color = Color(0xFFB9D9FF))
        }
    }
}

@Composable
fun EmptyHistory() {
    Column(Modifier.fillMaxWidth().padding(vertical = 45.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.ReceiptLong, null, modifier = Modifier.size(46.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = .7f))
        Spacer(Modifier.height(8.dp))
        Text("لا توجد حركات محفوظة بعد", fontWeight = FontWeight.SemiBold)
        Text("ستظهر هنا العمليات التي بدأتها", fontSize = 12.sp)
    }
}
