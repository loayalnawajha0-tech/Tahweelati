package com.loay.tahweelati

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Teal = Color(0xFF12B8F3)
private val Navy = Color(0xFF071333)
private val Panel = Color(0xFF101F4A)
private val ElectricBlue = Color(0xFF087BFF)
private val Violet = Color(0xFF792BFF)

@Serializable
data class Transfer(
    val id: Long,
    val wallet: String,
    val kind: String,
    val recipient: String,
    val amount: String,
    val note: String,
    val date: String,
    val code: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("tahweelati", MODE_PRIVATE)
        setContent {
            var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
            val scheme = if (dark) darkColorScheme(
                primary = Color(0xFF19B9FF), secondary = Color(0xFF9B5CFF),
                background = Navy, surface = Panel,
                onSurface = Color(0xFFF4F7FF), onBackground = Color(0xFFF4F7FF)
            ) else lightColorScheme(
                primary = Color(0xFF087BFF), secondary = Color(0xFF792BFF),
                background = Color(0xFFF4F8F7), surface = Color.White,
                onSurface = Color(0xFF19343D), onBackground = Color(0xFF19343D)
            )
            MaterialTheme(colorScheme = scheme) {
                TahweelatiApp(
                    dark = dark,
                    onDarkChange = { dark = it; prefs.edit().putBoolean("dark", it).apply() },
                    loadTransfers = {
                        runCatching { Json.decodeFromString<List<Transfer>>(prefs.getString("history", "[]") ?: "[]") }
                            .getOrDefault(emptyList())
                    },
                    saveTransfers = { prefs.edit().putString("history", Json.encodeToString(it)).apply() }
                )
            }
        }
    }
}

private fun buildUssd(wallet: String, kind: String, phone: String, amount: String): String? {
    val prefix = when (wallet to kind) {
        "جوال باي" to "لصديق" -> "*110*1*"
        "جوال باي" to "لتاجر" -> "*110*2*"
        "بال باي" to "لصديق" -> "*370*1*1*"
        // PalPay merchant code was not confirmed by the user; intentionally disabled.
        else -> return null
    }
    return "$prefix$phone*$amount#"
}

@Composable
fun TahweelatiApp(
    dark: Boolean,
    onDarkChange: (Boolean) -> Unit,
    loadTransfers: () -> List<Transfer>,
    saveTransfers: (List<Transfer>) -> Unit
) {
    val context = LocalContext.current
    var wallet by remember { mutableStateOf("جوال باي") }
    var kind by remember { mutableStateOf("لصديق") }
    var recipient by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var historyFilter by remember { mutableStateOf("الكل") }
    var transfers by remember { mutableStateOf(loadTransfers()) }
    var tab by remember { mutableIntStateOf(0) }
    var activeWalletScreen by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var pendingCode by remember { mutableStateOf<String?>(null) }
    var isBankMenu by remember { mutableStateOf(false) }
    var isBalanceCheck by remember { mutableStateOf(false) }

    val walletAccent = when (wallet) {
        "جوال باي" -> Color(0xFF159B55)
        "بال باي" -> Color(0xFF7B35B5)
        else -> Color(0xFFB3264A)
    }

    fun validateAndPrepare() {
        error = ""
        isBalanceCheck = false
        if (wallet == "بنك فلسطين") {
            isBankMenu = true
            pendingCode = "*267#"
            return
        }
        if (wallet == "بال باي" && kind == "لتاجر") {
            error = "كود بال باي للدفع لتاجر غير مؤكد، لذلك تم تعطيل هذا الخيار حتى تزويدنا بالكود الرسمي."
            return
        }
        val cleanPhone = recipient.filter { it.isDigit() }
        if (cleanPhone.length != 10 || !cleanPhone.startsWith("05")) {
            error = "أدخل رقم جوال فلسطيني صحيحاً بصيغة 05XXXXXXXX."
            return
        }
        val parsedAmount = amount.trim().replace(',', '.').toBigDecimalOrNull()
        if (parsedAmount == null || parsedAmount <= java.math.BigDecimal.ZERO) {
            error = "المبلغ إلزامي ويجب أن يكون أكبر من صفر."
            return
        }
        val normalizedAmount = parsedAmount.stripTrailingZeros().toPlainString()
        val code = buildUssd(wallet, kind, cleanPhone, normalizedAmount)
        if (code == null) {
            error = "صيغة هذا التحويل غير متاحة حالياً."
            return
        }
        isBankMenu = false
        pendingCode = code
    }

    fun prepareJawwalBalanceCheck() {
        isBankMenu = false
        isBalanceCheck = true
        pendingCode = "*268*3#"
    }

    fun openDialer(code: String) {
        val date = SimpleDateFormat("yyyy/MM/dd - HH:mm:ss", Locale.getDefault()).format(Date())
        if (!isBalanceCheck) {
            val item = Transfer(
                id = System.currentTimeMillis(), wallet = wallet,
                kind = if (isBankMenu) "قائمة خدمات" else kind,
                recipient = if (isBankMenu) "" else recipient.filter { it.isDigit() },
                amount = if (isBankMenu) "—" else amount.trim(),
                note = if (isBankMenu) "تم فتح قائمة خدمات بنك فلسطين" else note.trim(),
                date = date, code = code
            )
            transfers = listOf(item) + transfers
            saveTransfers(transfers)
        }
        val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", code, null))
        context.startActivity(intent)
        pendingCode = null
        isBalanceCheck = false
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0; activeWalletScreen = false },
                    icon = { Icon(Icons.Default.SwapHoriz, null) }, label = { Text("الرئيسية") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1; activeWalletScreen = false },
                    icon = { Icon(Icons.Default.History, null) }, label = { Text("السجل") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2; activeWalletScreen = false },
                    icon = { Icon(Icons.Default.Settings, null) }, label = { Text("الإعدادات") })
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)
                .then(if (tab == 1) Modifier else Modifier.verticalScroll(rememberScrollState()))
        ) {
            if (tab == 0 && !activeWalletScreen) {
                Header(dark = dark, onToggleTheme = { onDarkChange(!dark) })
                DashboardHome(
                    onWallet = { selected -> wallet = selected; activeWalletScreen = true; error = ""; recipient = ""; amount = ""; note = "" },
                    onBalance = { wallet = "جوال باي"; prepareJawwalBalanceCheck() }
                )
            } else {
            if (tab == 0 && activeWalletScreen) {
                WalletPageHeader(wallet = wallet, onBack = { activeWalletScreen = false }, dark = dark, onToggleTheme = { onDarkChange(!dark) })
            } else {
                Header(dark = dark, onToggleTheme = { onDarkChange(!dark) })
            }
            when (tab) {
                0 -> {
                    Text("تحويل جديد", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("اختر الخدمة وأدخل بيانات التحويل", fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                    Spacer(Modifier.height(12.dp))
                    CardBlock {
                        Text("1. نوع الدفع", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("لصديق", "لتاجر").forEach { option ->
                                FilterChip(selected = kind == option, onClick = { kind = option; error = "" },
                                    label = { Text(if (option == "لصديق") "🧑‍🤝‍🧑 دفع لصديق" else "🏪 دفع لتاجر") })
                            }
                        }
                        Text(
                            if (kind == "لصديق") "إرسال مبلغ إلى شخص تعرفه باستخدام رقم جواله."
                            else "دفع قيمة مشترياتك أو خدماتك لدى متجر أو تاجر.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("2. اختر المحفظة", fontWeight = FontWeight.Bold)
                        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("جوال باي", "بال باي", "بنك فلسطين").forEach { option ->
                                WalletChoice(option, wallet == option) { wallet = option; error = "" }
                            }
                        }
                        if (wallet == "بنك فلسطين") {
                            Spacer(Modifier.height(8.dp))
                            Text("سيتم فتح قائمة خدمات بنك فلسطين عبر الكود *267#.",
                                fontSize = 12.sp, color = walletAccent)
                        } else {
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = recipient, onValueChange = { recipient = it.filter { c -> c.isDigit() || c == '+' }.take(13); error = "" },
                                modifier = Modifier.fillMaxWidth(), label = { Text("3. رقم الجوال (إلزامي)") },
                                placeholder = { Text("05XXXXXXXX") }, leadingIcon = { Icon(Icons.Default.Phone, null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = walletAccent, focusedLabelColor = walletAccent,
                                    cursorColor = walletAccent, focusedLeadingIconColor = walletAccent
                                )
                            )
                            Spacer(Modifier.height(9.dp))
                            OutlinedTextField(
                                value = amount, onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' || c == ',' }; error = "" },
                                modifier = Modifier.fillMaxWidth(), label = { Text("4. المبلغ بالشيكل (إلزامي)") },
                                placeholder = { Text("مثال: 100") }, leadingIcon = { Icon(Icons.Default.Payments, null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = walletAccent, focusedLabelColor = walletAccent,
                                    cursorColor = walletAccent, focusedLeadingIconColor = walletAccent
                                )
                            )
                            Spacer(Modifier.height(9.dp))
                            OutlinedTextField(value = note, onValueChange = { note = it },
                                modifier = Modifier.fillMaxWidth(), label = { Text("5. ملاحظات (اختياري)") },
                                leadingIcon = { Icon(Icons.Default.EditNote, null) }, minLines = 2,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = walletAccent, focusedLabelColor = walletAccent,
                                    cursorColor = walletAccent, focusedLeadingIconColor = walletAccent
                                ))
                        }
                        if (wallet == "بال باي" && kind == "لتاجر") {
                            Text("كود الدفع لتاجر غير مؤكد حالياً", color = MaterialTheme.colorScheme.error,
                                fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        if (wallet == "جوال باي") {
                            OutlinedButton(
                                onClick = { prepareJawwalBalanceCheck() },
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                shape = RoundedCornerShape(15.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = walletAccent),
                                border = androidx.compose.foundation.BorderStroke(1.5.dp, walletAccent)
                            ) {
                                Icon(Icons.Default.AccountBalanceWallet, null)
                                Spacer(Modifier.width(8.dp))
                                Text("فحص رصيد جوال باي", fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                        if (error.isNotBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { validateAndPrepare() }, modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = walletAccent)) {
                            Icon(Icons.Default.Dialpad, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (wallet == "بنك فلسطين") "اتصال بخدمات البنك" else "اتصال", fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Text("لن يتم تنفيذ التحويل تلقائياً. ستفتح لوحة الاتصال لتراجع الكود وتكمل العملية بنفسك.",
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                }
                1 -> {
                    Text("سجل الحركات", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("ابحث برقم الجوال أو المحفظة أو الملاحظات") },
                        leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("الكل", "جوال باي", "بال باي", "بنك فلسطين").forEach { filter ->
                            FilterChip(
                                selected = historyFilter == filter,
                                onClick = { historyFilter = filter },
                                label = { Text(filter, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = when (filter) {
                                        "جوال باي" -> Color(0xFF159B55).copy(alpha = .18f)
                                        "بال باي" -> Color(0xFF7B35B5).copy(alpha = .18f)
                                        "بنك فلسطين" -> Color(0xFFB3264A).copy(alpha = .18f)
                                        else -> MaterialTheme.colorScheme.primary.copy(alpha = .15f)
                                    },
                                    selectedLabelColor = when (filter) {
                                        "جوال باي" -> Color(0xFF159B55)
                                        "بال باي" -> Color(0xFF7B35B5)
                                        "بنك فلسطين" -> Color(0xFFB3264A)
                                        else -> MaterialTheme.colorScheme.primary
                                    }
                                )
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    val filtered = transfers
                        .filter { historyFilter == "الكل" || it.wallet == historyFilter }
                        .filter { listOf(it.wallet, it.recipient, it.amount, it.note, it.date).any { value -> value.contains(search, true) } }
                        .sortedByDescending { it.id }
                    if (filtered.isEmpty()) EmptyHistory() else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filtered, key = { it.id }) { item ->
                            CardBlock {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.wallet, fontWeight = FontWeight.Bold)
                                        Text(
                                            if (item.wallet == "بنك فلسطين") item.kind
                                            else "${item.kind} • ${item.recipient}",
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            if (item.wallet == "بنك فلسطين") item.date
                                            else "${item.amount} ₪  |  ${item.date}",
                                            fontSize = 11.sp, color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            if (item.wallet == "بنك فلسطين") "تم فتح قائمة الخدمات — لا يعني تنفيذ تحويل"
                                            else "تم فتح لوحة الاتصال — غير مؤكد الإتمام",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f)
                                        )
                                        if (item.note.isNotBlank()) Text(item.note, fontSize = 11.sp)
                                    }
                                    IconButton(onClick = { transfers = transfers.filterNot { it.id == item.id }; saveTransfers(transfers) }) {
                                        Icon(Icons.Default.DeleteOutline, "حذف")
                                    }
                                }
                            }
                        }
                    }
                }
                else -> {
                    Text("الإعدادات", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    CardBlock {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("المظهر", fontWeight = FontWeight.Bold)
                                Text("التبديل بين الوضع الداكن والنهاري", fontSize = 12.sp)
                            }
                            Switch(checked = dark, onCheckedChange = onDarkChange)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    CardBlock {
                        Text("خصوصية وأمان", fontWeight = FontWeight.Bold)
                        Text("أكواد الاتصال محفوظة داخل التطبيق ولا تظهر ضمن الواجهة. راجع تفاصيل العملية قبل فتح لوحة الاتصال.",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .75f))
                    }
                    Spacer(Modifier.height(12.dp))
                    CardBlock {
                        Text("حول التطبيق", fontWeight = FontWeight.Bold)
                        Text("تحويلاتي", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        Text("برمجة وتصميم م. لؤي النواجحة", fontWeight = FontWeight.Medium)
                        Text("الإصدار 1.1", fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("المطور: م. لؤي النواجحة", modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center, fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
            Spacer(Modifier.height(6.dp))
        }
        }
    }

    if (pendingCode != null) {
        AlertDialog(
            onDismissRequest = { pendingCode = null },
            title = { Text(when {
                isBalanceCheck -> "فحص رصيد جوال باي"
                isBankMenu -> "قائمة بنك فلسطين"
                else -> "مراجعة كود التحويل"
            }) },
            text = {
                Column {
                    Text(when {
                        isBalanceCheck -> "سيتم فتح لوحة الاتصال لفحص رصيد محفظة جوال باي:"
                        isBankMenu -> "سيتم فتح قائمة خدمات بنك فلسطين عبر الكود التالي:"
                        else -> "راجع بياناتك والكود قبل الانتقال إلى لوحة الاتصال:"
                    })
                    Spacer(Modifier.height(10.dp))
                    Surface(color = MaterialTheme.colorScheme.background, shape = RoundedCornerShape(12.dp)) {
                        Text(pendingCode ?: "", modifier = Modifier.fillMaxWidth().padding(14.dp),
                            textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    if (!isBankMenu && !isBalanceCheck) Text("تأكد من رقم المستلم والمبلغ. لا تؤكد أي عملية لا تعرفها.", fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { openDialer(pendingCode!!) }) { Text("فتح الاتصال") } },
            dismissButton = { TextButton(onClick = { pendingCode = null }) { Text("رجوع") } }
        )
    }
}


@Composable
fun DashboardHome(onWallet: (String) -> Unit, onBalance: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent)) {
            Box(Modifier.fillMaxWidth().background(
                Brush.linearGradient(listOf(Color(0xFF071B36), Color(0xFF123D59), Color(0xFF711E3A)))
            ).padding(18.dp)) {
                Column {
                    Text("أسرع.. أسهل.. وأكثر أماناً", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Text("كل تحويلاتك في مكان واحد", color = Color(0xFFE0EAF7), fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("فلسطين دائماً في قلوبنا ♥", color = Color.White.copy(alpha = .9f), fontSize = 12.sp)
                }
            }
        }
        Text("اختر محفظتك", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Text("ابدأ عملية تحويل جديدة بسهولة", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            HomeWalletTile("بنك فلسطين", R.drawable.wallet_bank, Color(0xFFB3264A), Modifier.weight(1f)) { onWallet("بنك فلسطين") }
            HomeWalletTile("بال باي", R.drawable.wallet_palpay, Color(0xFF7026A8), Modifier.weight(1f)) { onWallet("بال باي") }
            HomeWalletTile("جوال باي", R.drawable.wallet_jawwal, Color(0xFF159B55), Modifier.weight(1f)) { onWallet("جوال باي") }
        }
        CardBlock {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.wallet_ussd), null, Modifier.size(52.dp), contentScale = ContentScale.Fit)
                Column(Modifier.weight(1f)) {
                    Text("فحص رصيد جوال باي", fontWeight = FontWeight.Bold)
                    Text("الوصول السريع لخدمة فحص الرصيد", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                }
                Button(onClick = onBalance, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF159B55))) {
                    Text("اتصال")
                }
            }
        }
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("تحويلاتك تحت سيطرتك", fontWeight = FontWeight.Bold)
                    Text("راجع تفاصيل العملية قبل فتح لوحة الاتصال", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun HomeWalletTile(name: String, logo: Int, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.height(132.dp).clickable { onClick() },
        shape = RoundedCornerShape(19.dp),
        colors = CardDefaults.cardColors(containerColor = tint),
        elevation = CardDefaults.cardElevation(5.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Image(painterResource(logo), contentDescription = name, modifier = Modifier.size(55.dp), contentScale = ContentScale.Fit)
            Spacer(Modifier.height(7.dp))
            Text(name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun WalletPageHeader(wallet: String, onBack: () -> Unit, dark: Boolean, onToggleTheme: () -> Unit) {
    val tint = when(wallet) {
        "جوال باي" -> Color(0xFF159B55)
        "بال باي" -> Color(0xFF7026A8)
        else -> Color(0xFFB3264A)
    }
    val logo = when(wallet) {
        "جوال باي" -> R.drawable.wallet_jawwal
        "بال باي" -> R.drawable.wallet_palpay
        else -> R.drawable.wallet_bank
    }
    Card(
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 14.dp),
        shape = RoundedCornerShape(bottomStart = 22.dp, bottomEnd = 22.dp, topStart = 18.dp, topEnd = 18.dp),
        colors = CardDefaults.cardColors(containerColor = tint)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "رجوع", tint = Color.White) }
            Image(painterResource(logo), wallet, Modifier.size(width = 66.dp, height = 42.dp), contentScale = ContentScale.Fit)
            Text(wallet, Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, textAlign = TextAlign.Center)
            IconButton(onClick = onToggleTheme) {
                Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "تغيير المظهر", tint = Color.White)
            }
        }
    }
}

@Composable
fun Header(dark: Boolean, onToggleTheme: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Image(painter = painterResource(id = R.drawable.app_logo), contentDescription = "شعار تحويلاتي",
            modifier = Modifier.size(58.dp), contentScale = ContentScale.Fit)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("تحويلاتي", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onBackground)
            Text("TAHWEELATI  •  محفظتك لإدارة التحويلات", fontSize = 10.sp,
                color = MaterialTheme.colorScheme.primary)
        }
        Surface(modifier = Modifier.clickable { onToggleTheme() },
            shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .35f))) {
            Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode,
                contentDescription = if (dark) "تفعيل الوضع النهاري" else "تفعيل الوضع الليلي",
                tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(11.dp))
        }
    }
}

@Composable
fun HeroBanner() {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier.fillMaxWidth().padding(bottom = 15.dp)) {
        Row(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF087A4B), Color(0xFF171F3D), Color(0xFF7A2438))))
            .padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("تحويلاتك أسهل وأسرع", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text("اختر محفظتك، أدخل البيانات، وراجع كود الاتصال قبل التأكيد", color = Color(0xFFB9D9FF), fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VerifiedUser, null, tint = Color(0xFF42E6D0), modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("تحكم كامل قبل تنفيذ أي عملية", color = Color(0xFF9CEDE5), fontSize = 10.sp)
                }
            }
            Image(painter = painterResource(id = R.drawable.app_logo), contentDescription = null,
                modifier = Modifier.size(100.dp), contentScale = ContentScale.Fit)
        }
    }
}

@Composable
fun CardBlock(content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(21.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), content = content)
    }
}

@Composable
fun WalletChoice(name: String, selected: Boolean, onClick: () -> Unit) {
    val tint = when (name) {
        "جوال باي" -> Color(0xFF22A765)
        "بال باي" -> Color(0xFF8B45C5)
        else -> Color(0xFFE13B83)
    }
    val logo = when (name) {
        "جوال باي" -> R.drawable.wallet_jawwal
        "بال باي" -> R.drawable.wallet_palpay
        else -> R.drawable.wallet_bank
    }
    Surface(modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(15.dp),
        color = if (selected) tint.copy(alpha = .12f) else MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 1.dp,
            if (selected) tint else MaterialTheme.colorScheme.onSurface.copy(alpha = .12f))) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painter = painterResource(id = logo), contentDescription = "شعار $name",
                modifier = Modifier.size(width = 76.dp, height = 42.dp), contentScale = ContentScale.Fit)
            Spacer(Modifier.width(12.dp))
            Text(name, Modifier.weight(1f), fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface)
            if (selected) Icon(Icons.Default.CheckCircle, null, tint = tint)
        }
    }
}

@Composable
fun EmptyHistory() {
    Column(Modifier.fillMaxWidth().padding(vertical = 45.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.ReceiptLong, null, modifier = Modifier.size(46.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = .7f))
        Spacer(Modifier.height(8.dp))
        Text("لا توجد حركات محفوظة بعد", fontWeight = FontWeight.SemiBold)
        Text("ستظهر هنا العمليات التي فتحت لها لوحة الاتصال", fontSize = 12.sp)
    }
}
